from flask import Flask, request, render_template, jsonify
import pandas as pd
from clickhouse_driver import Client
import os  # NEW

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

# ✅ Enhanced column fetching with table listing for ClickHouse
@app.route("/columns", methods=["POST"])
def get_columns():
    data = request.get_json()
    source = data.get("source")

    try:
        if source == "clickhouse":
            client = Client(
                host=data["host"],
                port=int(data["port"]),
                user=data["user"],
                password=data.get("jwt", ""),  # NEW: Made JWT optional
                database=data["database"],
                secure=True if str(data["port"]) in ['9440', '8443'] else False  # NEW: HTTPS support
            )
            
            # NEW: Fetch tables if no specific table provided
            if not data.get("table"):
                tables = client.execute("SHOW TABLES")
                return jsonify({"status": "success", "tables": [t[0] for t in tables]})
            
            result = client.execute(f"DESCRIBE TABLE {data['table']}")
            columns = [col[0] for col in result]
            return jsonify({"status": "success", "columns": columns})

        elif source == "flatfile":
            # NEW: Support different file encodings
            df = pd.read_csv(
                data["filename"], 
                delimiter=data["delimiter"],
                encoding='utf-8', 
                on_bad_lines='skip'
            )
            return jsonify({"status": "success", "columns": df.columns.tolist()})

    except Exception as e:
        return jsonify({"status": "error", "message": f"Failed to fetch columns: {str(e)}"})

# ✅ Complete bidirectional ingestion route
@app.route("/ingest", methods=["POST"])
def ingest():
    data = request.get_json()
    direction = data.get("direction")  # NEW: 'ch_to_flat' or 'flat_to_ch'
    source = data.get("source")
    columns = data.get("columns", [])
    
    try:
        if direction == "ch_to_flat":
            client = Client(
                host=data["host"],
                port=int(data["port"]),
                user=data["user"],
                password=data.get("jwt", ""),
                database=data["database"]
            )
            
            # NEW: Dynamic output filename
            output_file = data.get("output_file", "clickhouse_export.csv")
            col_str = ", ".join(columns) if columns else "*"
            
            query = f"SELECT {col_str} FROM {data['table']}"
            result = client.execute(query)
            
            df = pd.DataFrame(result, columns=columns or None)
            df.to_csv(output_file, index=False)
            return jsonify({
                "status": "success", 
                "count": len(df),
                "file": os.path.abspath(output_file)  # NEW: Return full path
            })

        elif direction == "flat_to_ch":
            # NEW: Full Flat File → ClickHouse implementation
            df = pd.read_csv(
                data["filename"],
                delimiter=data["delimiter"],
                usecols=columns if columns else None
            )
            
            client = Client(
                host=data["host"],
                port=int(data["port"]),
                user=data["user"],
                password=data.get("jwt", ""),
                database=data["database"]
            )
            
            # NEW: Auto-create table if not exists
            if not client.execute(f"EXISTS TABLE {data['table']}"):
                dtypes = {col: "String" for col in df.columns}  # Simplified type mapping
                cols_def = ", ".join([f"{k} {v}" for k,v in dtypes.items()])
                client.execute(f"CREATE TABLE {data['table']} ({cols_def}) ENGINE = Memory")
            
            # Batch insert
            client.execute(
                f"INSERT INTO {data['table']} VALUES",
                df.values.tolist(),
                types_check=True
            )
            
            return jsonify({
                "status": "success",
                "count": len(df),
                "table": data["table"]
            })

    except Exception as e:
        return jsonify({
            "status": "error", 
            "message": f"Ingestion failed: {str(e)}",
            "details": str(e.__class__.__name__)  # NEW: Error type
        })

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)