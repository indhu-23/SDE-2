document.addEventListener("DOMContentLoaded", function () {
    // Initialize UI
    toggleSourceFields();
    
    // Source selection handler
    document.getElementById("source").addEventListener("change", toggleSourceFields);
    
    // NEW: Direction change handler
    document.querySelectorAll('input[name="direction"]').forEach(radio => {
        radio.addEventListener("change", toggleDirectionFields);
    });

    // Auto-fetch columns when table or file is changed
    ["table", "filename", "delimiter"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener("blur", fetchColumns);
    });
});

// NEW: Toggle fields based on direction
function toggleDirectionFields() {
    const direction = document.querySelector('input[name="direction"]:checked').value;
    const isFlatToCh = direction === "flat_to_ch";
    
    document.getElementById("outputFileContainer").style.display = 
        (document.getElementById("source").value === "flatfile" && isFlatToCh) 
        ? "none" : "block";
}

function toggleSourceFields() {
    const isClickhouse = document.getElementById("source").value === "clickhouse";
    document.getElementById("clickhouseFields").style.display = isClickhouse ? "block" : "none";
    document.getElementById("flatFileFields").style.display = isClickhouse ? "none" : "block";
    document.getElementById("columnSelector").style.display = "none";
    document.getElementById("columnsArea").innerHTML = "";
    
    // NEW: Update direction fields
    toggleDirectionFields();
}

// NEW: Enhanced fetchColumns with progress indicators
function fetchColumns() {
    const source = document.getElementById("source").value;
    const direction = document.querySelector('input[name="direction"]:checked').value; // NEW
    
    // Validate required fields
    if (source === "clickhouse" && !document.getElementById("table").value) return;
    if (source === "flatfile" && !document.getElementById("filename").value) return;

    showProgress("Discovering columns..."); // NEW
    
    let payload = { 
        source,
        direction // NEW
    };

    if (source === "clickhouse") {
        payload = {
            ...payload,
            host: document.getElementById("host").value,
            port: document.getElementById("port").value,
            database: document.getElementById("database").value,
            user: document.getElementById("user").value,
            jwt: document.getElementById("jwt").value,
            table: document.getElementById("table").value
        };
    } else {
        payload = {
            ...payload,
            filename: document.getElementById("filename").value,
            delimiter: document.getElementById("delimiter").value || ","
        };
    }

    fetch("/columns", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    })
    .then(res => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.json();
    })
    .then(res => {
        const area = document.getElementById("columnsArea");
        area.innerHTML = "";
        
        if (res.status === "success") {
            document.getElementById("columnSelector").style.display = "block";
            
            // NEW: Better column display with select all header
            area.innerHTML = `
                <div class="column-header">
                    <label><input type="checkbox" id="selectAllCols"> Select All</label>
                </div>
            `;
            
            res.columns.forEach(col => {
                area.innerHTML += `
                    <div class="column-item">
                        <input type="checkbox" name="col" value="${col}" checked>
                        <label>${col}</label>
                    </div>
                `;
            });
            
            // NEW: Select all functionality
            document.getElementById("selectAllCols").addEventListener("click", function() {
                document.querySelectorAll('#columnsArea input[name="col"]').forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
            });
        } else {
            showError(res.message || "Failed to fetch columns");
        }
    })
    .catch(error => {
        showError(error.message);
    })
    .finally(() => {
        hideProgress(); // NEW
    });
}

// NEW: Enhanced submitForm with progress tracking
function submitForm() {
    const source = document.getElementById("source").value;
    const direction = document.querySelector('input[name="direction"]:checked').value; // NEW
    
    // Validate required fields
    const requiredFields = {
        clickhouse: ["host", "port", "database", "table"],
        flatfile: ["filename"]
    };
    
    for (const field of requiredFields[source]) {
        if (!document.getElementById(field).value) {
            showError(`Please fill in the ${field} field`);
            return;
        }
    }

    showProgress("Starting data ingestion...");
    updateProgress(10, "Preparing data"); // NEW
    
    let data = { 
        source,
        direction // NEW
    };

    // Add source-specific data
    if (source === "clickhouse") {
        data = {
            ...data,
            host: document.getElementById("host").value,
            port: document.getElementById("port").value,
            database: document.getElementById("database").value,
            user: document.getElementById("user").value,
            jwt: document.getElementById("jwt").value,
            table: document.getElementById("table").value
        };
    } else {
        data = {
            ...data,
            filename: document.getElementById("filename").value,
            delimiter: document.getElementById("delimiter").value || ","
        };
        
        // NEW: Only add output file for CH → Flat direction
        if (direction === "ch_to_flat") {
            data.output_file = document.getElementById("outputFile").value || "output.csv";
        }
    }

    // Get selected columns
    const selectedCols = Array.from(document.querySelectorAll('input[name="col"]:checked'))
        .map(el => el.value);
    data.columns = selectedCols.length > 0 ? selectedCols : null;

    updateProgress(30, "Sending request to server"); // NEW
    
    fetch("/ingest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(async res => {
        const result = await res.json();
        if (!res.ok) throw new Error(result.message || "Ingestion failed");
        return result;
    })
    .then(res => {
        updateProgress(100, "Ingestion complete!"); // NEW
        
        // NEW: Enhanced result display
        const resultEl = document.getElementById("result");
        resultEl.style.display = "block";
        resultEl.style.backgroundColor = "#f0fff0";
        resultEl.style.padding = "15px";
        resultEl.style.borderRadius = "8px";
        
        if (res.status === "success") {
            resultEl.innerHTML = `
                <div style="color: #2e7d32; font-weight: bold;">✅ ${res.message}</div>
                ${res.count ? `<div>Processed records: ${res.count.toLocaleString()}</div>` : ''}
                ${res.file ? `<div>Saved to: <code>${res.file}</code></div>` : ''}
                ${res.table ? `<div>Target table: <strong>${res.table}</strong></div>` : ''}
            `;
        } else {
            showError(res.message);
        }
    })
    .catch(error => {
        showError(error.message);
    })
    .finally(() => {
        setTimeout(hideProgress, 2000); // NEW: Keep progress visible briefly
    });
}

// NEW: Helper functions
function showProgress(message) {
    document.getElementById("progress").style.display = "block";
    document.getElementById("progressText").textContent = message;
    document.getElementById("progressBar").style.width = "0%";
}

function updateProgress(percent, message) {
    document.getElementById("progressBar").style.width = percent + "%";
    document.getElementById("progressText").textContent = message;
}

function hideProgress() {
    document.getElementById("progress").style.display = "none";
}

function showError(message) {
    const resultEl = document.getElementById("result");
    resultEl.style.display = "block";
    resultEl.style.backgroundColor = "#fff0f0";
    resultEl.style.padding = "15px";
    resultEl.style.borderRadius = "8px";
    resultEl.innerHTML = `<div style="color: #c62828;">❌ ${message}</div>`;
}